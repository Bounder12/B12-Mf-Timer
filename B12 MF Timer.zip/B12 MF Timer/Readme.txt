B12 MF Timer Readme

ALWAYS RUN AS ADMIN, It needs permisions to read and write to files to peform properly.
Made with AHK so .AHK files is the source for you to play with. Dont have ahk just run the exes

This tool is an automatic mf timer

For it to automatically detect when your creating a new game, it checks 2 sets of pixel colors.
For example, I use 2 silver corners on the lobby (see example screenshot)

Setup:
1. Run the ConfigurationTool when on the screen you want it to check for.
2. Click into your diablo instance so diablo itself is your active window
3. Press ctrl+1 to save the first location and color (Automatically updates the ini)
4. Press ctrl+2 to save the second location and color (Automatically updates the ini)
5. Press ctrl+x to close the ConfigurationTool
6. Launch the timer and test

Once configured, so long as you do not change your game resolution and the like it will continue to work
If you do change your screen/monitor/graphics card just rerun the configuration tool

I advise you reset or start it when your in your first game

Exports:
It will save a file with your current date and time in the same directory as the program. You are free to change it to csv and manipulate as you like.

Hotkeys:
ctrl+p to pause

Tips:

Multiplayer user lobby screen,

Single Player use dificulty selection screen

Known Bugs:

Runlist cannot be scrolled through while it is running, to scroll through it stop it.